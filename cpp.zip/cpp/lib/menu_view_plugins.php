<?php


if (! defined( 'ABSPATH' ) ) { die( 'Forbidden' ); }

// =====================================================================
// Display Plugins & Theme stats.

$buffer = cpp_get_profile_data( $profile_path, 'slugs' );
if ( isset( $buffer['error'] ) ) {
	return;
}

// Fetch options
$cp_options = get_option( 'cpp' );

// Name vs slug
if ( empty( $cp_options['display_name'] ) || ! in_array( $cp_options['display_name'], ['full', 'slug' ] ) ) {
	$cp_options['display_name'] = 'full';
}
// Truncate name
if ( empty( $cp_options['truncate_name'] ) || ! preg_match( '/^\d+$/', ( $cp_options['truncate_name'] ) ) ) {
	$cp_options['truncate_name'] = 30;
}
// Horizontal vs vertical chart
if ( empty( $cp_options['chart_type'] ) || ! in_array( $cp_options['chart_type'], ['x', 'y' ] ) ) {
	$axis = 'x';
} else {
	$axis = $cp_options['chart_type'];
}
// Max plugins to display
if ( empty( $cp_options['chart_max_plugins'] ) || ! preg_match( '/^\d+$/', ( $cp_options['chart_max_plugins'] ) ) ) {
	$chart_max_plugins = 25;
} else {
	$chart_max_plugins = $cp_options['chart_max_plugins'];
}

// Check if we should warn about composer
if (! empty( $cp_options['warn_composer'] ) ) {
	$composer_warning = cpp_composer_warning( $profile_path, $cp_options['display_name'] );
}

$label		= '';
$data			= '';
$theme		= esc_attr__('theme', 'cpp');
$total_time	= 0;
$hidden		= 0;
$count		= 0;
// Sort by value
usort( $buffer, function( $a, $b ) {
	return $b[1] <=> $a[1];
} );
foreach( $buffer as $k => $slugs ) {

	if ( empty( $slugs[1] ) && ! empty( $cp_options['hide_empty_value'] ) ) {
		$hidden++;
		$hidden_empty = 1;
		continue;
	}

	$count++;
	if ( $count > $chart_max_plugins ) {
		$hidden++;
		$hidden_max_plugins = 1;
		continue;
	}

	// Check whether we should use the name or the slug
	if ( $cp_options['display_name'] == 'slug' ) {
		$n = $slugs[0];
	} else {
		$n = $slugs[2];
	}

	// Truncate and sanitise the name
	if ( strlen( $n ) > $cp_options['truncate_name'] ) {
		$n = mb_substr( $n, 0, $cp_options['truncate_name'] , 'utf-8') .'...';
	}
	$n = addslashes( $n );

	// Mark theme as such
	if ( $slugs[3] == 'theme' ) {
		$label .= "'{$n} ($theme)',";
	// ...and MU plugins
	} elseif ( $slugs[3] == 'mu-plugin' ) {
		$label .= "'{$n} (MU)',";
	} else {
		$label .= "'{$n}',";
	}

	$data 		.= "{$slugs[1]},";
	$total_time	+= $slugs[1];
}
$label = rtrim( $label, ',' );
$data  = rtrim( $data, ',' );

?>
<div style="width:80vw;margin:auto">
	<canvas id="myChart"></canvas>
</div>
<script>
jQuery(document).ready(function() {
	'use strict';
	cpjspro_plugins_chart(
		'<?php echo $axis ?>', [<?php echo $label ?>],
		[<?php echo esc_js( $data ) ?>], <?php echo esc_js( number_format( $total_time, 4 ) ) ?>
	);
});
</script>
<?php
// Actions below stats
$save_png	= 1;
$save_csv	= 1;
$rotate_img	= 1;
$type			= 'slugs';

// =====================================================================
// Warn if multiple plugins are using composer

function cpp_composer_warning( $profile_path, $display_name ) {

	if (! file_exists( "$profile_path.composer.profile" ) ) {
		return;
	}
	$res = json_decode( file_get_contents( "$profile_path.composer.profile" ), true );
	if ( $res === false ) {
		return;
	}

	$list = '';
	foreach( $res as $slug => $name ) {
		if ( $display_name == 'full' ) {
			$list .= '<strong>'. esc_html( $name ) .'</strong>, ';
		} else {
			$list .= '<strong>'. esc_html( $slug ) .'</strong>, ';
		}
	}
	$list = rtrim( $list, ', ' ) .'.';

	$msg = sprintf(
		esc_html__('C P has detected that the following items, sorted by execution order, are using Composer dependency manager: %s', 'cpp'),
		$list
	) .'<br />'.
	esc_html__('In order to read and interpret the chart, make sure to consult the FAQ page.', 'cpp') ;

	return '<div class="cp-notice cp-notice-orange"><p>'. $msg .'</p></div>';

}
// =====================================================================
// EOF
