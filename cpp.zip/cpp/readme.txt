=== CPP - WordPress Performance Profiling and Debugging Made Easy ===
Tags: seo, performance, optimize, benchmark, profiling, statistics, debug, speed
Requires at least: 5.0
Tested up to: 7.0
Stable tag: 1.4.4
License: GPLv3 or later
Requires PHP: 7.1
License URI: http://www.gnu.org/licenses/gpl-3.0.html

A profiler to measure the performance of your WordPress plugins and themes.

== Description ==

= A profiler to measure the performance of your WordPress plugins and themes. =

CPP helps you to measure the performance of your plugins and themes at the PHP level and to quickly find any potential problem in your WordPress installation.

You can profile the frontend and backend of WordPress, a custom URL, or even send a POST payload and custom cookies to profile a contact form, a checkout process or an AJAX action among many other possibilities.

It generates an extremely detailed and easy to read analysis in the form of charts and tables that shows not only which plugin or theme, but also which PHP script, class, method and function is slowing down your website. It displays many useful additional information such as database queries, file I/O operations and disk I/O usage as well.

It makes it very simple to locate any bottleneck problem in your themes or plugins in order to solve it and speed up your website.
Install, activate it and you can start profiling your site right away.