<?php
/*
 +=====================================================================+
 |    ____          _        ____             __ _ _                   |
 |   / ___|___   __| | ___  |  _ \ _ __ ___  / _(_) | ___ _ __         |
 |  | |   / _ \ / _` |/ _ \ | |_) | '__/ _ \| |_| | |/ _ \ '__|        |
 |  | |__| (_) | (_| |  __/ |  __/| | | (_) |  _| | |  __/ |           |
 |   \____\___/ \__,_|\___| |_|   |_|  \___/|_| |_|_|\___|_|           |
 |                                                                     |
 |  (c) Jerome Bruandet ~ https://code-profiler.com/                   |
 +=====================================================================+
*/

if (! defined( 'ABSPATH' ) ) { die( 'Forbidden' ); }

// =====================================================================

class CodeProfilerPro_Profiler {

	static $tick_list;
	static $buffer = 10000000;
	static $metrics;

	private $tmp_iostats;
	private $tmp_summary;
	private $tmp_iolist;
	private $tmp_diskio;
	private $tmp_ticks;

	/*
	 * Initialize
	 */
	public function __construct() {

		$microtime = sanitize_file_name( $_REQUEST['CODE_PROFILER_PRO_ON'] );

		$this->tmp_summary = CODE_PROFILER_PRO_UPLOAD_DIR ."/$microtime." .
									CODE_PROFILER_PRO_TMP_SUMMARY_LOG;
		$this->tmp_iostats = CODE_PROFILER_PRO_UPLOAD_DIR ."/$microtime." .
									CODE_PROFILER_PRO_TMP_IOSTATS_LOG;
		$this->tmp_iolist  = CODE_PROFILER_PRO_UPLOAD_DIR ."/$microtime." .
									CODE_PROFILER_PRO_TMP_IOLIST_LOG;
		$this->tmp_ticks   = CODE_PROFILER_PRO_UPLOAD_DIR ."/$microtime." .
									CODE_PROFILER_PRO_TMP_TICKS_LOG;
		$this->tmp_diskio	 = CODE_PROFILER_PRO_UPLOAD_DIR ."/$microtime." .
									CODE_PROFILER_PRO_TMP_DISKIO_LOG;
		$this->tmp_queries = CODE_PROFILER_PRO_UPLOAD_DIR ."/$microtime." .
									CODE_PROFILER_PRO_TMP_QUERY_LOG;

		// Clear the temporary log because the buffer will be written
		// with the FILE_APPEND flag
		if ( file_exists( $this->tmp_ticks ) ) {
			unlink( $this->tmp_ticks );
		}

		if ( version_compare( PHP_VERSION, '7.3', '<' ) ) {
			self::$metrics = 'microtime';
		} else {
			self::$metrics = 'hrtime';
		}

		// Enable queries debugging
		if (! defined( 'SAVEQUERIES' ) ) {
			define('SAVEQUERIES', true);
		}
		if (! defined( 'QM_DISABLED' ) ) {
			// Temporarily disable Query Monitor
			// so that we can fetch the DB queries
			define('QM_DISABLED', true);
		}

		register_shutdown_function( array( $this, 'code_profiler_pro_shutdown' ) );
		require 'class-stream.php';
		CodeProfilerPro_Stream::start();
		register_tick_function( array( $this, 'code_profiler_pro_tick_handler' ) );
	}


	/*
	 * Save data and check for potential PHP errors.
	 */
	public function code_profiler_pro_shutdown() {

		CodeProfilerPro_Stream::stop();

		global $wpdb;
		if (! empty( $this->tmp_queries ) ) {
			// Prevent a "Serialization of Closure is not allowed"
			// potential error message
			try {
				file_put_contents( $this->tmp_queries , serialize( $wpdb->queries ) );
			} catch ( Exception $e ) {
				code_profiler_pro_log_error(
					esc_html('Cannot serialize DB queries object, is that a closure?', 'code-profiler-pro')
				);
			}
		} else{
			code_profiler_pro_log_warn(
				esc_html('DB queries object is empty.', 'code-profiler-pro')
			);
		}

		// Restore wp-content/db.php
		if ( file_exists( WP_CONTENT_DIR .'/db.php.code-profiler') ) {
			rename( WP_CONTENT_DIR .'/db.php.code-profiler', WP_CONTENT_DIR .'/db.php');
			code_profiler_pro_log_info(
				sprintf(
					/* Translators: Restoring wp-content/db.php */
					esc_html__('Restoring %s', 'code-profiler-pro' ),
					WP_CONTENT_DIR .'/db.php'
				)
			);
		}

		$summary['memory']	= memory_get_peak_usage();
		$summary['queries']	= get_num_queries() - 2;
		file_put_contents( $this->tmp_summary, json_encode( $summary ) );

		// Catch potential error
		$e = error_get_last();
		if ( isset( $e['type'] ) && $e['type'] === E_ERROR ) {
			$err = str_replace( "\n", ' - ', $e['message'] );
			code_profiler_pro_log_error( sprintf(
			/* Translators: Error message, line number and script */
				esc_html__('Error: E_ERROR (%s - line %s in %s)', 'code-profiler-pro'),
				esc_html( $err ),
				(int) $e['line'],
				esc_html( $e['file'] )
			));
		}

		$err_msg = esc_html__('Cannot open file for writting: %s', 'code-profiler-pro');
		$res = file_put_contents( $this->tmp_iostats, json_encode( CodeProfilerPro_Stream::$io_stats ) );
		if ( $res === false ) {
			$msg = sprintf( $err_msg, $this->tmp_iostats );
			code_profiler_pro_log_error( $msg );
		}

		$res = file_put_contents( $this->tmp_iolist, CodeProfilerPro_Stream::$io_list );
		if ( $res === false ) {
			$msg = sprintf( $err_msg, $this->tmp_iolist );
			code_profiler_pro_log_error( $msg );
		}

		$res = file_put_contents( $this->tmp_ticks, self::$tick_list, FILE_APPEND );
		if ( $res === false ) {
			$msg = sprintf( $err_msg, $this->tmp_ticks );
			code_profiler_pro_log_error( $msg );
		}
		$res = file_put_contents(
			$this->tmp_diskio, "read\t". CodeProfilerPro_Stream::$io_read ."\nwrite\t".
			CodeProfilerPro_Stream::$io_write
		);

	}

	/*
	 * Our tick handler.
	 */
	public function code_profiler_pro_tick_handler() {

		if ( self::$metrics == 'hrtime' ) {
			$start = hrtime( true );
		} else {
			$start = microtime( true );
		}

		$backtrace = debug_backtrace( DEBUG_BACKTRACE_IGNORE_ARGS, 2 );
		if ( isset( $backtrace[1] ) ) {
			$el = $backtrace[1];
		} else {
			$el = $backtrace[0];
		}

		if ( empty( $el['file'] ) || empty( $el['line'] ) ) {
			return;
		}

		self::$tick_list .= "{$el['file']}\t{$el['line']}\t";
		if ( isset( $el['class'] ) ) {
			self::$tick_list .= "{$el['class']}";
			if ( isset( $el['type'] ) ) {
				self::$tick_list .= "{$el['type']}";
			} else {
				self::$tick_list .= '->';
			}
		}
		if ( isset( $el['function'] ) ) {
			self::$tick_list .= "{$el['function']}";
		}
		self::$tick_list .= "\t";
		if ( isset( $backtrace[0]['file'][0] ) ) {
			self::$tick_list .= $backtrace[0]['file'];
		} else {
			self::$tick_list .= '-';
		}

		if ( self::$metrics == 'hrtime' ) {
			self::$tick_list .="\t{$start}\t". hrtime(true) ."\n";
		} else {
			self::$tick_list .="\t{$start}\t". microtime(true) ."\n";
		}

		// Buffer can grow very big (several hundred megabytes),
		// hence we flush it every 10MB by default
		if ( strlen( self::$tick_list ) > self::$buffer ) {
			CodeProfilerPro_Stream::stop();
			file_put_contents( $this->tmp_ticks, self::$tick_list, FILE_APPEND );
			CodeProfilerPro_Stream::start();
			self::$tick_list = '';
		}
	}
}

new CodeProfilerPro_Profiler();

// =====================================================================
// EOF
