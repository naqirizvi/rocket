<?php


if (! defined( 'ABSPATH' ) ) { die( 'Forbidden' ); }

// =====================================================================
// Display the profiler's support page.

echo cpp_display_tabs( 6 );
?>
<br />
<p><?php esc_html_e('When contacting the support for help, please copy and paste the system information report below in your ticket:', 'cpp' ) ?></p>
<table class="form-table">
	<tr>
		<td>
			<textarea dir="auto" id="cp-troubleshooter" class="large-text code" style="height:250px;" wrap="off" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false"><?php
			require_once __DIR__ .'/class-troubleshooter.php';
			new CPPro_Troubleshooter();
			?></textarea>
			<p><input type="button" onClick="cpjspro_copy_textarea('cp-troubleshooter')" class="button-secondary" value="<?php esc_attr_e('Copy text', 'cpp') ?>" /></p>
		</td>
	</tr>
</table>
<?php

// =====================================================================
// EOF
