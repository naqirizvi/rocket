<?php


if (! defined( 'ABSPATH' ) ) { die( 'Forbidden' ); }

// =====================================================================
// Display FAQ tab.


echo cpp_display_tabs( 5 );

?>
<br />
<table class="widefat">
	<tr>
		<td style="border-bottom:1px solid #c3c4c7">
			<h4><?php esc_html_e('What is C P?', 'cpp' ) ?></h4>
			<?php esc_html_e('C P measures the performance of your plugins and themes at the PHP level, and helps you to quickly find any potential problem in your WordPress installation. It generates an extremely detailed and easy to read analysis in the form of charts and tables that shows not only which plugin or theme, but also which PHP script, class, method and function is slowing down your website. It displays many useful additional information such as file I/O operations and disk I/O usage as well.', 'cpp' ) ?>
			<br />
			<?php esc_html_e('It makes it very simple to locate any speed problem in your themes or plugins in order to solve it and speed up your website.', 'cpp' ) ?>
		</td>
	</tr>
	<tr>
		<td style="border-bottom:1px solid #c3c4c7">
			<h4><?php esc_html_e('Will C P work if I have a caching plugin or a PHP opcode cache, or if my website is using a CDN service?', 'cpp' ) ?></h4>
			<?php esc_html_e('In most cases, C P will be able to bypass caching from plugins and CDN services, as well as your PHP opcode cache. If there were a problem, it would warn you about it.', 'cpp' ) ?>
		</td>
	</tr>
	<tr>
		<td style="border-bottom:1px solid #c3c4c7">
			<h4><?php esc_html_e('Why do I see numbers such as "3E-06" or "1.2E-05" after opening the CSV file with my spreadsheet editor?', 'cpp' ) ?></h4>
			<?php esc_html_e('Spreadsheet editors such as LibreOffice Calc and Microsoft Excel can use scientific exponential notation to display very small numbers, for instance, 0.000025 will become 2.5e-5. Select the whole column of numbers and, in the toolbar of your spreadsheet editor, click the button to increase the number of decimals to 6.', 'cpp' ) ?>
		</td>
	</tr>
	<tr>
		<td style="border-bottom:1px solid #c3c4c7">
			<h4><?php esc_html_e('Do I need to deactivate C P when I\'m not using it ?', 'cpp' ) ?></h4>
			<?php esc_html_e('There\'s no need to deactivate C P when you don\'t use it, it has no performance impact on your site.', 'cpp' ) ?>
		</td>
	</tr>
	<tr>
		<td style="border-bottom:1px solid #c3c4c7">
			<h4><?php esc_html_e('Why do some scripts show an execution time of 0 second?', 'cpp' ) ?></h4>
			<?php esc_html_e('That can happen if your PHP version is 7.1 or 7.2. With those versions, C P can only use microseconds for its metrics, while with versions 7.3 and above it can use the system\'s high resolution time in nanoseconds. It can also happen if a PHP script has only a couple of lines of code, its execution time is too quick to be measured, hence it will show 0.', 'cpp' ) ?>
		</td>
	</tr>
	<tr>
		<td style="border-bottom:1px solid #c3c4c7">
			<h4><?php esc_html_e('Is it possible to exclude a plugin during the profiling?', 'cpp' ) ?></h4>
			<?php
			printf(
				esc_html__('You can exclude one or more plugins during the profiling by using the %sFreesoul Deactivate Plugins%s plugin available in the WordPress.org repo:', 'cpp' ),
				'<a href="https://wordpress.org/plugins/freesoul-deactivate-plugins/" target="_blank" rel="noopener noreferrer">',
				'</a>'
			);
			echo '<ul>'.
				'<ol>'. esc_html__('Download, install and activate the plugin.', 'cpp' ) .'</ol>'.
				'<ol>'. esc_html__('Go to its main page, click the gear icon and select "C P".', 'cpp' ) .'</ol>'.
				'<ol>'. esc_html__('Select the "According to this page settings" option, uncheck the plugin(s) you want to exclude during the profiling and save your settings.', 'cpp' ) .'</ol>'.
				'<ol>'. esc_html__('Go back to C P\'s page and run it.', 'cpp' ) .'</ol>'.
			'</ul>';
				?>
		</td>
	</tr>
	<tr>
		<td style="border-bottom:1px solid #c3c4c7">
			<h4><?php esc_html_e('Why does C P P warn me that I have multiple plugins using Composer?', 'cpp' ) ?></h4>
			<?php
			echo esc_html_e('Composer, a tool for dependency management in PHP, is included in many popular plugins and themes. It is used to autoload PHP classes.', 'cpp' ) .
			'<br />' .
			esc_html__('C P (Pro version only) will inform you if two or more activated plugins use it because you will need to take it into consideration when reading and interpreting the results. Let\'s take an example:', 'cpp' ).
			'<br />' .
			esc_html__('Assuming you have 4 plugins: A, B, C and D. Both plugins A and D include and require Composer. WordPress will start and load plugin A, which will run an instance of Composer to load its classes. Immediately after, WordPress will load plugins B and C. Then, it will load plugin D, which too will need to load its classes. However, plugin D will not start a new instance of Composer but, instead, will rely on the one from plugin A to load its own classes.', 'cpp' ).
			'<br />' .
			esc_html__('As a result, the execution time of plugin A will increase (its instance of Composer is used to load classes for plugin C too), while the execution time of plugin C will decrease (it doesn\'t need to start a new instance of Composer).', 'cpp' ).
			'<br />' .
			esc_html__('That is not a problem at all when you are profiling your website but, assuming you are a developer and just want to profile a plugin that you wrote and that includes Composer, you will need to disable any other plugin using Composer in order to get the most accurate results for your plugin only.', 'cpp' );
			?>
			<br />&nbsp;
		</td>
	</tr>
	<tr>
		<td style="border-bottom:1px solid #c3c4c7">
			<h4><?php esc_html_e('Is C P multisite compatible?', 'cpp' ) ?></h4>
			<?php esc_html_e('C P is multisite compatible. Note however that for security reasons, only the superadmin can run it.', 'cpp' ) ?>
		</td>
	</tr>
	<tr>
		<td style="border-bottom:1px solid #c3c4c7">
			<h4><?php esc_html_e('What are the requirements for running C P?', 'cpp' ) ?></h4>
			<?php esc_html_e('It requires at least WordPress 5.0 and PHP 7.1. It is compatible with PHP 8.', 'cpp' ) ?>
		</td>
	</tr>
	<tr>
		<td>
			<h4><?php esc_html_e('What is your Privacy Policy?', 'cpp' ) ?></h4>
			<?php esc_html_e('C P does not collect any private data from you or your visitors. It does not use cookies either. Your website can run C P and be compliant with privacy laws such as the General Data Protection Regulation (GDPR) or the California Consumer Privacy Act (CCPA).', 'cpp' ) ?>
		</td>
	</tr>
</table>
<?php

// =====================================================================
// EOF
