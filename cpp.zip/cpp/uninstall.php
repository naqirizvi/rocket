<?php


if (! defined('WP_UNINSTALL_PLUGIN') ) { exit('Not allowed'); }

// =====================================================================
// C P's uninstaller (database + files).

$cp_options = get_option('cpp');

global $wp_filesystem;
require_once ABSPATH . 'wp-admin/includes/file.php';
WP_Filesystem();

define('CPP_VERSION', '1');
require_once 'lib/helper.php';

// Delete profiles on disk (optional)
if (! empty( $cp_options['uninstall_delete_profiles'] ) ) {
	// Find and recursively delete any files and folders
	// located inside the profiles directory:
	$wp_filesystem->delete( CPP_UPLOAD_DIR, true, 'd');
}

if ( $wp_filesystem->exists( WPMU_PLUGIN_DIR .'/'. CPP_MUPLUGIN ) ) {
	$wp_filesystem->delete( WPMU_PLUGIN_DIR .'/'. CPP_MUPLUGIN, false, 'f');
}

// Delete options in the DB
delete_option('cpp');

return;

// =====================================================================
// EOF
