<?php


if (! defined( 'ABSPATH' ) ) { die( 'Forbidden' ); }

// =====================================================================
// Display contextual help below each chart and table.

if ( $type == 'slugs' ) {

	?>
	<table class="widefat">
		<tr>
			<td><h4><?php echo $section_list[ $section ] ?></h4>
				<p>
					<?php esc_html_e('This chart shows the execution time of all activated plugins and the current theme, in seconds and percentage, for the current profile. It can be downloaded as an image or even exported as a CSV file (comma-separated values) that you can open with your favorite spreadsheet editor.', 'cpp' ) ?>
				</p>
			</td>
		</tr>
	</table>
	<?php

} elseif ( $type == 'scripts' ) {

	?>
	<table class="widefat">
		<tr>
			<td><h4><?php echo $section_list[ $section ] ?></h4>
				<p>
					<?php esc_html_e('That section shows the time it took for each PHP script to execute its code while your website was loading. The "Time" column shows their respective processing time in seconds and, with a green horizontal bar, the percentage it represents.', 'cpp' ) ?>
				</p>
			</td>
		</tr>
	</table>
	<?php

} elseif ( $type == 'functions' ) {

	?>
	<table class="widefat">
		<tr>
			<td><h4><?php echo $section_list[ $section ] ?></h4>
				<p>
					<?php esc_html_e('That section shows the time it took for each class/method or function to execute its code while your website was loading. The "Time" column shows their respective processing time in seconds and, with a green horizontal bar, the percentage it represents. The "Caller" column shows the sum of all function(s) that called it.', 'cpp' ) ?>
					<br />
					<?php esc_html_e('The two action links below each item let you view the corresponding function, or the list of all callers.', 'cpp' ) ?>
				</p>
				<p>
					<?php echo esc_html__('In addition to method and function names, the following labels can be found in the "Function" column:', 'cpp' ) .'<br /><code>{main}</code>: '. esc_html__('It means the whole script was called, not just a specific method, using a PHP function such a require or include, which you can view by clicking on the "View caller" link.', 'cpp' ) .'<br /><code>{closure}</code>: '. esc_html__('It means it is an anonymous function, i.e., a function that can be created without a specified name.', 'cpp' ) ?>
				</p>
			</td>
		</tr>
	</table>
	<?php

} elseif ( $type == 'queries' ) {

	?>
	<table class="widefat">
		<tr>
			<td><h4><?php echo $section_list[ $section ] ?></h4>
				<p>
					<?php esc_html_e('That section shows the time it took to process each database query. Note that only queries from the plugins and the theme are displayed, not WordPress core queries.', 'cpp' ) ?>
					<br />
					<?php esc_html_e('The "Time" column shows their respective processing time in seconds and, with a green horizontal bar, the percentage it represents. The "Order" column lets you sort them by execution order.', 'cpp' ) ?>
					<br />
					<?php esc_html_e('The "View backtrace" action link below each item lets you view a list of the scripts and function calls that lead to the query, sorted by execution order.', 'cpp' ) ?>
				</p>
			</td>
		</tr>
	</table>
	<?php

} elseif ( $type == 'iolist' ) {

	?>
	<table class="widefat">
		<tr>
			<td><h4><?php echo $section_list[ $section ] ?></h4>
				<p>
					<?php esc_html_e('That section shows all files and directories with their respective I/O operations that occurred while your website was loading. The default sorting order is based on the control flow, i.e., the order in which the PHP code was executed while the website was loading. The following 10 operations are monitored by C P:', 'cpp' ) ?>
				</p>
				<p>
					<?php esc_html_e('Open file (read & write), delete file, rename file or directory, remove directory, make directory, open directory, change mode, change group, change owner and change timestamps.', 'cpp' ) ?>
				</p>
				<p>
					<?php esc_html_e('Every files will be displayed. For instance, if a plugin or theme created a temporary file or wrote to a log, it would appear in the list too.', 'cpp' ); echo ' '; esc_html_e('Regarding open file operations, C P displays the mode parameter used to specify the type of access. It may be any of the following:', 'cpp' ) ?>
				</p>
				<table class="widefat" style="border:none;box-shadow:none">
					<tr>
						<td style="width:50%">
							<code>r</code>: <?php esc_html_e('Open for reading only; place the file pointer at the beginning of the file.', 'cpp' ) ?>
						</td>
						<td style="width:50%">
							<code>r+</code>: <?php esc_html_e('Open for reading and writing; place the file pointer at the beginning of the file.', 'cpp' ) ?>
						</td>
					</tr>
					<tr>
						<td>
							<code>w</code>: <?php esc_html_e('Open for writing only; place the file pointer at the beginning of the file and truncate the file to zero length. If the file does not exist, attempt to create it.', 'cpp' ) ?>
						</td>
						<td>
							<code>w+</code>: <?php esc_html_e('Open for reading and writing; otherwise it has the same behavior as \'w\'.', 'cpp' ) ?>
						</td>
					</tr>
					<tr>
						<td>
							<code>a</code>: <?php esc_html_e('Open for writing only; place the file pointer at the end of the file. If the file does not exist, attempt to create it. In this mode, fseek has no effect, writes are always appended.', 'cpp' ) ?>
						</td>
						<td>
							<code>a+</code>: <?php esc_html_e('Open for reading and writing; place the file pointer at the end of the file. If the file does not exist, attempt to create it. In this mode, fseek only affects the reading position, writes are always appended.', 'cpp' ) ?>
						</td>
					</tr>
					<tr>
						<td>
							<code>x</code>: <?php esc_html_e('Create and open for writing only; place the file pointer at the beginning of the file. If the file does not exist, attempt to create it.', 'cpp' ) ?>
						</td>
						<td>
							<code>x+</code>: <?php esc_html_e('Create and open for reading and writing; otherwise it has the same behavior as \'x\'.', 'cpp' ) ?>
						</td>
					</tr>
					<tr>
						<td>
							<code>c</code>: <?php esc_html_e('Open the file for writing only. If the file does not exist, it is created. If it exists, it is neither truncated (as opposed to \'w\'), nor the call to this function fails (as is the case with \'x\'). The file pointer is positioned on the beginning of the file.', 'cpp' ) ?>
						</td>
						<td>
							<code>c+</code>: <?php esc_html_e('Open the file for reading and writing; otherwise it has the same behavior as \'c\'.', 'cpp' ) ?>
						</td>
					</tr>
					<tr>
						<td>
							<code>e</code>: <?php esc_html_e('Set close-on-exec flag on the opened file descriptor. Only available in PHP compiled on POSIX.1-2008 conform systems.', 'cpp' ) ?>
						</td>
						<td>&nbsp;</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	<?php

} elseif ( $type == 'iostats' ) {

	?>
	<table class="widefat">
		<tr>
			<td><h4><?php echo $section_list[ $section ] ?></h4>
				<p><?php esc_html_e('The chart displays all file I/O operations that occurred while your website was loading. The following operations are monitored by C P:', 'cpp' ) ?></p>
				<table class="widefat" style="border:none;box-shadow:none">
					<tr>
						<td style="width:50%">
							<code>cast</code>: <?php esc_html_e('Retrieve the underlaying resource (stream_select).', 'cpp' ) ?>
						</td>
						<td style="width:50%">
							<code>chgrp</code>: <?php esc_html_e('Change file group.', 'cpp' ) ?>
						</td>
					</tr>
					<tr>
						<td>
							<code>chmod</code>: <?php esc_html_e('Change file mode.', 'cpp' ) ?>
						</td>
						<td>
							<code>chown</code>: <?php esc_html_e('Change file owner.', 'cpp' ) ?>
						</td>
					</tr>
					<tr>
						<td>
							<code>close</code>: <?php esc_html_e('Close a resource (fclose).', 'cpp' ) ?>
						</td>
						<td>
							<code>closedir</code>: <?php esc_html_e('Close directory handle.', 'cpp' ) ?>
						</td>
					</tr>
					<tr>
						<td>
							<code>eof</code>: <?php esc_html_e('Test for end-of-file on a file pointer (feof).', 'cpp' ) ?>
						</td>
						<td>
							<code>flush</code>: <?php esc_html_e('Flush the output (fflush).', 'cpp' ) ?>
						</td>
					</tr>
					<tr>
						<td>
							<code>lock</code>: <?php esc_html_e('Advisory file locking (flock).', 'cpp' ) ?>
						</td>
						<td>
							<code>mkdir</code>: <?php esc_html_e('Create a directory.', 'cpp' ) ?>
						</td>
					</tr>
					<tr>
						<td>
							<code>open</code>: <?php esc_html_e('Open file (e.g., fopen, file_get_contents).', 'cpp' ) ?>
						</td>
						<td>
							<code>opendir</code>: <?php esc_html_e('Open directory handle.', 'cpp' ) ?>
						</td>
					</tr>
					<tr>
						<td>
							<code>read</code>: <?php esc_html_e('Read from stream (e.g., fread, fgets).', 'cpp' ) ?>
						</td>
						<td>
							<code>readdir</code>: <?php esc_html_e('Read entry from directory handle.', 'cpp' ) ?>
						</td>
					<tr>
					<tr>
						<td>
							<code>rename</code>: <?php esc_html_e('Rename a file or directory.', 'cpp' ) ?>
						</td>
						<td>
							<code>rewinddir</code>: <?php esc_html_e('Rewind directory handle.', 'cpp' ) ?>
						</td>
					</tr>
					<tr>
						<td>
							<code>rmdir</code>: <?php esc_html_e('Remove a directory.', 'cpp' ) ?>
						</td>
						<td>
							<code>seek</code>: <?php esc_html_e('Seek to specific location in a stream (fseek).', 'cpp' ) ?>
						</td>
					</tr>
					<tr>
						<td>
							<code>set_option</code>: <?php esc_html_e('Change stream options.', 'cpp' ) ?>
						</td><td>
							<code>stat</code>: <?php esc_html_e('Retrieve information about a file resource (fstat).', 'cpp' ) ?>
						</td>
					</tr>
					<tr>
						<td>
							<code>tell</code>: <?php esc_html_e('Retrieve the current position of a stream. (fseek).', 'cpp' ) ?>
						</td><td>
							<code>truncate</code>: <?php esc_html_e('Truncate stream (ftruncate).', 'cpp' ) ?>
						</td>
					</tr>
					<tr>
						<td>
							<code>touch</code>: <?php esc_html_e('Set access and modification time of file.', 'cpp' ) ?>
						</td>
						<td>
							<code>unlink</code>: <?php esc_html_e('Delete a file.', 'cpp' ) ?>
						</td>
					</tr>
					<tr>
						<td>
							<code>url_stat</code>: <?php esc_html_e('Retrieve information about a file. This method is called in response to all stat related functions, such as copy, filesize, filetype, is_dir, is_file, file_exists etc.', 'cpp' ) ?>
						</td>
						<td>
							<code>write</code>: <?php esc_html_e('Write to stream (fwrite).', 'cpp' ) ?>
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	<?php

} elseif ( $type == 'diskio' ) {

	?>
	<table class="widefat">
		<tr>
			<td><h4><?php echo $section_list[ $section ] ?></h4>
				<p><?php esc_html_e('The chart shows the total amount of disk I/O read and write data, in bytes, that occurred while your website was loading. It includes all activated plugins, the current theme and also WordPress.', 'cpp' ) ?></p>

			</td>
		</tr>
	</table>
	<?php
} elseif ( $type == 'license' ) {

	?>
	<table class="widefat">
		<tr>
			<td>
				<p><?php esc_html_e('You can use your license on the following subdomains as well, at no extra cost:', 'cpp') ?></p>
				<ul class="license-help-view" style="font-size:15px;">
					<li><?php printf( 'https://dev.%s/', esc_html( $cp_options['domain'] ) ) ?></li>
					<li><?php printf( 'https://local.%s/', esc_html( $cp_options['domain'] ) ) ?></li>
					<li><?php printf( 'https://stage.%s/', esc_html( $cp_options['domain'] ) ) ?></li>
					<li><?php printf( 'https://staging.%s/', esc_html( $cp_options['domain'] ) ) ?></li>
					<li><?php printf( 'https://test.%s/', esc_html( $cp_options['domain'] ) ) ?></li>
					<li><?php printf( 'https://testing.%s/', esc_html( $cp_options['domain'] ) ) ?></li>
				</ul>
			</td>
		</tr>
	</table>
	<?php

// Profiles list
} elseif ( $type == 'profiles_list' ) {

	?>
	<table class="widefat">
		<tr>
			<td><h4><?php esc_html_e('Profiles List', 'cpp') ?></h4>
				<p><?php esc_html_e('This page shows all saved profiles with sortable columns:', 'cpp') ?></p>
				<ul class="license-help-view" style="font-size:15px;">
					<li><?php esc_html_e('Profile: name of the saved profile.', 'cpp') ?></li>
					<li><?php esc_html_e('Date: creation date of the profile.', 'cpp') ?></li>
					<li><?php esc_html_e('Items: number of plugins + the current theme.', 'cpp') ?></li>
					<li><?php esc_html_e('Time: execution time in second.', 'cpp') ?></li>
					<li><?php esc_html_e('Memory: peak memory in megabytes.', 'cpp') ?></li>
					<li><?php esc_html_e('File I/O: sum of all file I/O operations.', 'cpp') ?></li>
					<li><?php esc_html_e('SQL: sum of database queries (WordPress, all plugins and the theme).', 'cpp') ?></li>
				</ul>
			</td>
		</tr>
	</table>
	<?php
}
// =====================================================================
// EOF
