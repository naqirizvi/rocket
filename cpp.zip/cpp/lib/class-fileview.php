<?php

if (! defined( 'ABSPATH' ) ) { die( 'Forbidden' ); }

// =====================================================================

class CodeProfilerPro_FileView {

	private $ffile;
	private $ffunction;
	private $fline;

	/*
	 * Initialize.
	 */
	public function __construct( $ffile, $ffunction ='' , $fline = 0 ) {

		$this->ffile = $ffile;
		$this->ffunction = $ffunction;
		$this->fline = $fline;

		$this->parse_file();
	}

	/*
	 * Parse the file to display.
	 */
	private function parse_file() {

		$content = file( $this->ffile );
		if ( $content === false ){
			wp_die( sprintf(
				esc_html__('Cannot read file: %s', 'cpp' ),
				esc_html( $this->ffile )
			) );
		}

		// We have a line number, decrement it to match the zero-based array
		if (! empty( $this->fline ) ) {
			$this->fline--;
		}

		// We have a function/method, let's find it
		if (! empty( $this->ffunction ) ) {
			$this->find_function_linenum( $content );
		}

		$this->display_content( $content );
	}

	/*
	 * Find the caller.
	 */
	private function find_function_linenum( $content ) {

		$ffunction = preg_quote( $this->ffunction );

		$count = 0;
		foreach( $content as $line ) {
			if ( preg_match("/\bfunction\s+{$ffunction}\s*\(/", $line ) ) {
				$this->fline = $count;
				return;
			}
			$count++;
		}
	}

	/*
	 * Display the formatted content.
	 */
	private function display_content( $content ) {

		$buffer = '';
		foreach( $content as $line ) {
			$buffer .= $line;
		}

		// Get file extension
		$extension = pathinfo( $this->ffile, PATHINFO_EXTENSION );
		if ( $extension == 'php' ) {
			$mode = 'application/x-httpd-php';
		} elseif ( $extension == 'css' ) {
			$mode = 'text/css';
		} elseif ( in_array( $extension, ['js', 'json' ] ) ) {
			 $mode = 'text/javascript';
		} else {
			$mode = 'text/html';
		}

		?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
	<head>
		<link rel="stylesheet" href="<?php echo plugins_url( '/static/vendor/codemirror.min.css', dirname( __FILE__ ) ) ?>">
		<link rel="stylesheet" href="<?php echo plugins_url( '/static/cpp.css', dirname( __FILE__ ) ) ?>">
		<script src="<?php echo plugins_url( '/static/vendor/codemirror.min.js', dirname( __FILE__ ) ) ?>"></script>
		<script src="<?php echo plugins_url( '/static/vendor/lib/matchbrackets.min.js', dirname( __FILE__ ) ) ?>"></script>
		<script src="<?php echo plugins_url( '/static/vendor/lib/xml.min.js', dirname( __FILE__ ) ) ?>"></script>
		<script src="<?php echo plugins_url( '/static/vendor/lib/htmlmixed.min.js', dirname( __FILE__ ) ) ?>"></script>
		<script src="<?php echo plugins_url( '/static/vendor/lib/javascript.min.js', dirname( __FILE__ ) ) ?>"></script>
		<script src="<?php echo plugins_url( '/static/vendor/lib/css.min.js', dirname( __FILE__ ) ) ?>"></script>
		<script src="<?php echo plugins_url( '/static/vendor/lib/clike.min.js', dirname( __FILE__ ) ) ?>"></script>
		<script src="<?php echo plugins_url( '/static/vendor/lib/php.min.js', dirname( __FILE__ ) ) ?>"></script>
		<script src="<?php echo plugins_url( '/static/vendor/lib/active-line.min.js', dirname( __FILE__ ) ) ?>"></script>
	</head>
<body class="cpview_body">
	<table class="cpview_table">
		<thead>
			<tr style="height:30px">
				<th colspan="2" style="text-align:center;"><?php printf( esc_html__('Viewing: %s', 'cpp' ), $this->ffile ) ?></th>
			</tr>
		</thead>
	</table>
	<p><textarea id="view-file" style="border:1px solid #ccc"><?php echo esc_textarea( $buffer ) ?></textarea></p>
	<h3 class="cpview_h3">C P &copy; <?php echo date('Y') ?> <a href="https://google.com/" target="_blank" rel="noopener noreferrer">Jerome Bruandet</a></h3>
	<script>
		'use strict';
		var editor = CodeMirror.fromTextArea(document.getElementById('view-file'), {
			lineNumbers: true,
			matchBrackets: true,
			mode: "<?php echo $mode ?>",
			indentUnit: 3,
			indentWithTabs: true,
			lineWrapping: true,
			lineNumbers: true,
			<?php
			if (! empty( $this->fline ) ) {
				?>
				styleActiveLine: true,
				<?php
			}
			?>
			readOnly: true
      });
		editor.setSize('100%', '100%');
		<?php
		if (! empty( $this->fline ) ) {
			// Couldn't find another (and simpler) way to center the active line
			?>
			editor.setCursor( {line: <?php echo $this->fline + 20 ?>} );
			editor.setCursor( {line: <?php echo $this->fline ?>} );
			<?php
		}
		?>
  </script>
</body>
</html>
<?php
		exit;
	}

}
// =====================================================================
// EOF
