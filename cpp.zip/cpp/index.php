<?php
/*
Plugin Name: CPP
Description: A profiler to measure the performance of your WordPress plugins and themes.
Version: 1.4.4
Network: true
License: GPLv3 or later
Text Domain: cpp
Domain Path: /languages
Network: true
*/

define( 'CPP_VERSION', '1.4.4' );

if (! defined( 'ABSPATH' ) ) { die( 'Forbidden' ); }

// =====================================================================
// Menu functions
require __DIR__ .'/lib/menu.php';
// Helper (can be already loaded by the MU plugin)
require_once __DIR__ .'/lib/helper.php';
// AJAX calls
require __DIR__ .'/lib/ajax.php';
// =====================================================================
// Activation: make sure the blog meets the requirements.

function cpp_activate() {

	if (! defined('WP_CLI') && ! current_user_can('activate_plugins') ) {
		exit( esc_html__( 'Your are not allowed to activate plugins.', 'cpp' ) );
	}

	global $wp_version;
	if ( version_compare( $wp_version, '4.7.0', '<' ) ) {
		exit( sprintf(
			esc_html__('C P requires WordPress %s or greater but your current version is %s.', 'cpp'),
			'4.7.0',
			esc_html( $wp_version )
		) );
	}

	if ( version_compare( PHP_VERSION, '7.1', '<' ) ) {
		exit( sprintf(
			esc_html__( 'C P requires PHP 7.1 or greater but your current version is %s.',
			'cpp' ),
			esc_html( PHP_VERSION )
		) );
	}

	// Verify/create our storage folder
	cpp_check_uploadsdir();

	// If we don't have any options yet, create them
	$cp_options = get_option( 'cpp' );
	if ( $cp_options === false ) {
		cpp_default_options();
	}

	// If the free version is active, we deactivate it
	if ( is_plugin_active( 'code-profiler/index.php' ) ) {
		deactivate_plugins( 'code-profiler/index.php' );
	}
}

register_activation_hook( __FILE__, 'cpp_activate' );

// =====================================================================
// Deactivation.

function cpp_deactivate() {

	if (! defined('WP_CLI') && ! current_user_can('activate_plugins') ) {
		exit( esc_html__( 'Your are not allowed to deactivate plugins.', 'cpp' ) );
	}

	// Remove the MU plugin
	if ( file_exists( WPMU_PLUGIN_DIR .'/'. CPP_MUPLUGIN ) ) {
		unlink( WPMU_PLUGIN_DIR .'/'. CPP_MUPLUGIN );
	}
}

register_deactivation_hook( __FILE__, 'cpp_deactivate' );

// =====================================================================
// Create Profiler's menu.

function cpp_admin_menu() {

	// In a MU environment, only the superadmin can run C P
	if (! is_super_admin() ) {
		return;
	}

	add_menu_page(
		'C P P',
		'C P P',
		'manage_options',
		'cpp',
		'cpp_main_menu',
		plugins_url( '/static/dashicon-16x16.png', __FILE__ )
	);
}

add_action( 'admin_menu', 'cpp_admin_menu' );

// =====================================================================
// Register scripts and styles.

function cpp_enqueue( $hook ) {

	if (! is_super_admin() ) { return; }

	// Load files only if we're in C P's main page
	if ( $hook != 'toplevel_page_cpp' ) { return; }

	wp_enqueue_script(
		'cpp_javascript',
		plugin_dir_url( __FILE__ ) . 'static/cpp.js',
		array( 'jquery' ),
		CPP_VERSION
	);

	wp_enqueue_script(
		'cp_pro_tiptip',
		plugin_dir_url( __FILE__ ) .'static/vendor/jquery.tipTip.js',
		array( 'jquery' ),
		CPP_VERSION
	);

	wp_enqueue_style(
		'cp_pro_style',
		plugin_dir_url( __FILE__ ) . 'static/cpp.css',
		[],
		CPP_VERSION
	);

	// Enqueue Chart.js if we're viewing a profile
	if ( isset( $_REQUEST['action'] ) && $_REQUEST['action'] == 'view_profile' ) {
		wp_enqueue_script(
			'cpp_charts',
			plugin_dir_url( __FILE__ ) . 'static/vendor/chart.min.js',
			array( 'jquery' ),
			CPP_VERSION,
			// We load it in the footer, because some plugins loads it too
			// on every pages and that could mess with our pages
			true
		);
	}

	// JS i18n
	$cpp_i18n = array(
		'missing_nonce' =>
			esc_attr__('Security nonce is missing, try to reload the page.', 'cpp' ),
		'missing_frontbackend' =>
			esc_attr__('Please select either the fontend or backend option.', 'cpp' ),
		'missing_profilename' =>
			esc_attr__('Please enter a name for this profile.', 'cpp' ),
		'missing_userauth' =>
			esc_attr__('Please select whether the profiler should run as an authenticated user or not.', 'cpp' ),
		'missing_username' =>
			esc_attr__('Please enter the name of the user.', 'cpp' ),
		'missing_post' =>
			esc_attr__('Please select a page to profile.', 'cpp' ),
		'unknown_error' =>
			esc_attr__('Unknown error returned by AJAX', 'cpp' ),
		'http_error' =>
			esc_attr__('The HTTP server returned the following error:', 'cpp'),
		'unknown_error' =>
			esc_attr__('An unknown error occurred:', 'cpp'),
		'preparing_report' =>
			esc_attr__('Preparing report', 'cpp') .'...',
		'empty_log' =>
			esc_attr__('No records were found that match the specified search criteria.', 'cpp'),
		'delete_log' =>
			esc_attr__('Delete log?', 'cpp'),
		'delete_profile' =>
			esc_attr__('Delete this profile?', 'cpp'),
		// Charts
		'exec_sec_plugins' =>
			esc_attr__('Execution time in seconds', 'cpp'),
		'pc_plugins' =>
			/* Translators: xx% of all plugins and the theme */
			esc_attr__('% of all plugins and the theme', 'cpp'),
		'exec_tot_plugins_1' =>
			esc_attr__('Plugins and theme execution time, in seconds', 'cpp'),
		'chart_total' =>
			esc_attr__('total:', 'cpp'),
		'iolist_total_calls' =>
			esc_attr__('Total calls', 'cpp'),
		'io_calls' =>
			esc_attr__('File I/O operations', 'cpp'),
		'disk_io_bytes' =>
			esc_attr__('Total bytes', 'cpp'),
		'disk_io_title' =>
			esc_attr__('Total Disk I/O read and write, in bytes', 'cpp'),
		'text_copied' =>
			esc_attr__('The text was successfully copied to the clipboard.', 'cpp')

	);
	wp_localize_script( 'cpp_javascript', 'cpi18n', $cpp_i18n );
}

add_action( 'admin_enqueue_scripts', 'cpp_enqueue' );

// =====================================================================
// Display the settings link in the "Plugins" page.

function cpp_settings_link( $links ) {

   $links[] = '<a href="'. get_admin_url( null, 'admin.php?page=cpp') .
					'">'.	esc_html__('Start Profiling', 'cpp'). '</a>';
	return $links;
}

add_filter( 'plugin_action_links_' . plugin_basename(__FILE__), 'cpp_settings_link' );

// =====================================================================
// Download data as a CSV file.

function cpp_download_csv() {

	// Only the superadmin can access this part
	if (! is_super_admin() ) {
		return;
	}

	if ( isset( $_GET['page'] ) && $_GET['page'] == 'cpp' &&
		isset( $_REQUEST['cp-download-csv'] ) &&
		preg_match('`^\d{10}\.\d+$`', $_REQUEST['cp-download-csv'] ) &&
		! empty( $_REQUEST['cp-type'] ) &&	in_array( $_REQUEST['cp-type'], [
			'profiles',
			'slugs',
			'scripts',
			'functions',
			'iolist',
			'iostats',
			'diskio',
			'queries' ] )
	) {

		if ( $_REQUEST['cp-type'] == 'profiles' ) {
			require_once __DIR__ .'/lib/class-export-list.php';
			new CodeProfilerPro_ExportList();

		} else {
			require_once __DIR__ .'/lib/class-export.php';
			new CodeProfilerPro_Export();
		}
	}
}

add_action('admin_init', 'cpp_download_csv' );

// =====================================================================
// File viewer.

function cpp_file_viewer() {

	// Only the superadmin can access this part
	if (! is_super_admin() ) {
		return;
	}

	if ( isset( $_GET['page'] ) && $_GET['page'] == 'cpp' &&
		isset( $_GET['ffile'] ) && isset( $_GET['fnonce'] ) ) {

		// Security nonce
		if ( wp_verify_nonce( $_GET['fnonce'], 'code-profile-view-file' ) === false ) {
			wp_die( esc_html__('Missing or wrong security nonce. Reload the page and try again', 'cpp') );
		}

		$ffile = base64_decode( $_GET['ffile'] );
		if ( $ffile === false ) {
			wp_die( esc_html__('File does not seem valid', 'cpp' ) );
		}

		if (! preg_match( '`^(?i:[a-z]:|/)`', $ffile ) || preg_match( '`\.\.\B`', $ffile ) ) {
			wp_die( sprintf(
				esc_html__('File does not seem valid: %s', 'cpp' ),
				esc_html( $ffile )
			) );
		}

		// File must be in the ABSPATH or DOCUMENT_ROOT (or the folder above them):
		if ( empty( $_SERVER['DOCUMENT_ROOT'] ) ) {
			$path_docroot = preg_quote( dirname( ABSPATH ) );
		} else {
			$path_docroot = preg_quote( dirname( $_SERVER['DOCUMENT_ROOT'] ) );
		}
		$path_abs = preg_quote( dirname( ABSPATH ) );
		if (! preg_match( "`^($path_abs|$path_docroot)`", realpath( $ffile ) ) ) {
			wp_die( sprintf(
				esc_html__('File is not in the ABSPATH or DOCUMENT_ROOT: %s', 'cpp' ),
				esc_html( $ffile )
			) );
		}

		$content = file_get_contents( $ffile );
		// We cannot display binaries
		cpp_is_binary( $content );

		// Check if we need to display a method/function and or line number
		$ffunction = ''; $fline = 0;
		if ( ! empty( $_GET['ffunction'] ) ) {
			$ffunction = $_GET['ffunction'];

		} elseif (! empty( $_GET['fline'] ) && preg_match( '/^\d+$/', $_GET['fline'] ) ) {
			$fline = $_GET['fline'];
		}

		require 'lib/class-fileview.php';
		new CodeProfilerPro_FileView( $ffile, $ffunction, $fline );

		exit;
	}

}

add_action('admin_init', 'cpp_file_viewer' );

// =====================================================================
// Check if the file is binary.

function cpp_is_binary( $content ) {

	if ( strpos( $content, "\x00" ) !== false ) {
		wp_die( esc_html__('This is a binary file and it cannot be viewed.', 'cpp') );
	}
}

// =====================================================================
// WP CLI commands.

if ( defined( 'WP_CLI' ) && WP_CLI ) {
	require_once __DIR__ . '/lib/class-cli.php';
}

// =====================================================================
// EOF
