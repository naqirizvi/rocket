<?php


if (! defined( 'ABSPATH' ) ) { die( 'Forbidden' ); }

// =====================================================================
// Display File I/O stats.

$buffer = cpp_get_profile_data( $profile_path, 'diskio' );
if ( isset( $buffer['error'] ) ) {
	return;
}

// Fetch options
$cp_options = get_option( 'cpp' );

// Horizontal vs vertical chart
if ( empty( $cp_options['chart_type'] ) || ! in_array( $cp_options['chart_type'], ['x', 'y' ] ) ) {
	$axis = 'x';
} else {
	$axis = $cp_options['chart_type'];
}

$label  = "'".
			esc_js( __('I/O Read bytes', 'cpp') ) .
			"', '".
			esc_js( __('I/O Write bytes', 'cpp') ) .
			"'";
$data   = "'". (int) $buffer[0][1] ."', '". (int) $buffer[1][1] ."'";
?>
<div style="width:80vw;margin:auto">
	<canvas id="myChart"></canvas>
</div>
<script>
jQuery(document).ready(function() {
	'use strict';
	cpjspro_diskio_chart(
		'<?php echo $axis ?>', [<?php echo $label ?>], [<?php echo $data ?>]
	);
});
</script>
<?php
// Actions below stats
$save_png   = 1;
$save_csv   = 1;
$rotate_img = 1;
$type       = 'diskio';
// =====================================================================
// EOF
