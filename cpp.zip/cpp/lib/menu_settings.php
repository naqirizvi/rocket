<?php


if (! defined( 'ABSPATH' ) ) { die( 'Forbidden' ); }

// =====================================================================
// Display Summary tab.

echo cpp_display_tabs( 3 );

// Save settings?
if (! empty( $_POST['save-settings'] ) ) {
	// Make sure we have security nonce
	if ( empty( $_POST['cp-save-settings'] ) || ! wp_verify_nonce($_POST['cp-save-settings'], 'cp_settings') ) {
		wp_nonce_ays('cp_settings');
	}
	$res = cpp_save_settings();
	if ( $res === true ) {
		printf( CPP_UPDATE_NOTICE, esc_html__('Your changes have been saved.', 'cpp' ) );
	}
	else {
		printf( CPP_ERROR_NOTICE, esc_html__('No changes were detected.', 'cpp' ) );
	}
}

// Fetch current options
$cp_options = get_option( 'cpp' );

?>
<form method="post">
	<?php wp_nonce_field('cp_settings', 'cp-save-settings', 0); ?>
	<table class="form-table">
		<?php

		// Paths
		if ( empty( $cp_options['show_paths'] ) || ! in_array( $cp_options['show_paths'], ['absolute', 'relative' ] ) ) {
			$cp_options['show_paths'] = 'relative';
		}
		?>
		<tr>
			<th scope="row"><?php esc_html_e('Paths','cpp') ?></th>
			<td>
				<p><label><input type="radio" name="cp_options[show_paths]"<?php checked( $cp_options['show_paths'], 'absolute' ) ?> value="absolute" /><?php printf( esc_html__('Show absolute paths (e.g., %s)','cpp'), esc_html( ABSPATH ) .'wp-admin/index.php' ) ?></label></p>
				<p><label><input type="radio" name="cp_options[show_paths]"<?php checked( $cp_options['show_paths'], 'relative' ) ?> value="relative" /><?php printf( esc_html__('Show relative paths (e.g., %s)','cpp'), 'wp-admin/index.php' ) ?></label></p>
			</td>
		</tr>

		<?php
		// Name vs slug
		if ( empty( $cp_options['display_name'] ) || ! in_array( $cp_options['display_name'], ['full', 'slug' ] ) ) {
			$cp_options['display_name'] = 'full';
		}
		// Truncate names
		if ( empty( $cp_options['truncate_name'] ) || ! preg_match( '/^\d+$/', ( $cp_options['truncate_name'] ) ) ) {
			$cp_options['truncate_name'] = 30;
		}
		?>
		<tr>
			<th scope="row"><?php esc_html_e('Plugins & Themes','cpp') ?></th>
			<td>
				<p><label><input type="radio" name="cp_options[display_name]"<?php checked( $cp_options['display_name'], 'full' ) ?> value="full" /><?php printf( esc_html__('Show real names (e.g., %s)','cpp'), 'Super Plugin Pro for WordPress' ) ?></label></p>
				<p><label><input type="radio" name="cp_options[display_name]"<?php checked( $cp_options['display_name'], 'slug' ) ?> value="slug" /><?php printf( esc_html__('Show slugs (e.g., %s)','cpp'), 'super-plugin-pro' ) ?></label></p>
				<br />
				<p><label><?php
					printf(
						esc_html__('Truncate names to %s characters', 'cpp'),
						'<input class="small-text" type="number" size="4" min="0" maxlength="100" name="cp_options[truncate_name]" value="'. (int) $cp_options['truncate_name'] .'" />'
					);
				?></label></p>
				<p class="description"><?php esc_html_e('A name longer than 30 characters will be difficult to read on most charts.', 'cpp') ?></p>
			</td>
		</tr>

		<?php
		// chart type
		if ( empty( $cp_options['chart_type'] ) || ! in_array( $cp_options['chart_type'], ['x', 'y' ] ) ) {
			$cp_options['chart_type'] = 'x';
		}
		// Max plugins to display
		if ( empty( $cp_options['chart_max_plugins'] ) || ! preg_match( '/^\d+$/', ( $cp_options['chart_max_plugins'] ) ) ) {
			$cp_options['chart_max_plugins'] = 25;
		}
		// Empty values
		if (! empty( $cp_options['hide_empty_value'] ) ) {
			$cp_options['hide_empty_value'] = 1;
		} else {
			$cp_options['hide_empty_value'] = 0;
		}
		// Max rows to display (tables)
		if ( empty( $cp_options['table_max_rows'] ) || ! preg_match( '/^\d+$/', ( $cp_options['table_max_rows'] ) ) ) {
			$cp_options['table_max_rows'] = 30;
		}
		// Truncate queries
		if ( empty( $cp_options['truncate_queries'] ) || ! preg_match( '/^\d+$/', ( $cp_options['truncate_queries'] ) ) ) {
			$cp_options['truncate_queries'] = 500;
		}
		?>
		<tr>
			<th scope="row"><?php esc_html_e('Tables & Charts','cpp') ?></th>
			<td>
				<p><label><input type="radio" name="cp_options[chart_type]"<?php checked( $cp_options['chart_type'], 'x' ) ?> value="x" /><?php esc_html_e('Display horizontal charts by default','cpp') ?></label></p>
				<p><label><input type="radio" name="cp_options[chart_type]"<?php checked( $cp_options['chart_type'], 'y' ) ?> value="y" /><?php esc_html_e('Display vertical charts by default','cpp') ?></label></p>
				<p class="description"><?php esc_html_e('You can switch between vertical and horizontal by clicking the corresponding button located below each chart.', 'cpp') ?></p>

				<br />

				<p><label><?php
					printf(
						esc_html__('Do not display more than %s plugins on a chart', 'cpp'),
						'<input class="small-text" type="number" size="3" min="1" maxlength="100" name="cp_options[chart_max_plugins]" value="'. (int) $cp_options['chart_max_plugins'] .'" />'
					);
				?></label></p>
				<p class="description"><?php esc_html_e('More than 30 plugins will be difficult to read on most charts. Note that only plugins that have a negligible impact on your website\'s performance will be hidden.', 'cpp') ?></p>

				<br />

				<p><label><?php
					printf(
						esc_html__('Do not display more than %s rows in a table', 'cpp'),
						'<input class="small-text" type="number" size="3" min="1" name="cp_options[table_max_rows]" value="'. (int) $cp_options['table_max_rows'] .'" />'
					);
				?></label></p>

				<br />

				<p><label><?php
					printf(
						esc_html__('Truncate database queries to %s characters', 'cpp'),
						'<input class="small-text" type="number" size="5" min="10" max="2048" name="cp_options[truncate_queries]" value="'. (int) $cp_options['truncate_queries'] .'" />'
					);
				?></label></p>

				<br />

				<p><label><input type="checkbox" name="cp_options[hide_empty_value]"<?php checked( $cp_options['hide_empty_value'], '1' ) ?> /><?php esc_html_e('Hide items that have an empty value.','cpp') ?></label></p>

				<p class="description"><?php esc_html_e('This options will hide items that have an empty value on all graphs and tables.', 'cpp') ?></p>

			</td>
		</tr>

		<?php
		// Composer warning
		if (! empty( $cp_options['warn_composer'] ) ) {
			$cp_options['warn_composer'] = 1;
		} else {
			$cp_options['warn_composer'] = 0;
		}
		// WP-CLI integration
		if (! empty( $cp_options['enable_wpcli'] ) ) {
			$cp_options['enable_wpcli'] = 1;
		} else {
			$cp_options['enable_wpcli'] = 0;
		}
		// Disable WP-CRON
		if (! empty( $cp_options['disable_wpcron'] ) ) {
			$cp_options['disable_wpcron'] = 1;
		} else {
			$cp_options['disable_wpcron'] = 0;
		}
		// Disable wp-content/db.php
		if (! empty( $cp_options['disable_db-php'] ) ) {
			$cp_options['disable_db-php'] = 1;
		} else {
			$cp_options['disable_db-php'] = 0;
		}

		// HTTP code to reject
		if (! empty( $cp_options['http_response'] ) ) {
			if (! preg_match( "/{$cp_options['http_response']}/", '300' ) ) {
				$http_response_300 = 0;
			} else {
				$http_response_300 = 1;
			}
			if (! preg_match( "/{$cp_options['http_response']}/", '400' ) ) {
				$http_response_400 = 0;
			} else {
				$http_response_400 = 1;
			}
			if (! preg_match( "/{$cp_options['http_response']}/", '500' ) ) {
				$http_response_500 = 0;
			} else {
				$http_response_500 = 1;
			}
		} else {
			$http_response_300 = 0;
			$http_response_400 = 0;
			$http_response_500 = 0;
		}
		?>
		<tr>
			<th scope="row"><?php esc_html_e('Various', 'cpp') ?></th>
			<td>
				<p><label><input type="checkbox" name="cp_options[warn_composer]"<?php checked( $cp_options['warn_composer'], '1' ) ?> /><?php esc_html_e('Show a notice when several plugins are using Composer dependency manager.','cpp') ?></label></p>

				<p class="description"><?php esc_html_e('Consult the FAQ page for more details about this option.', 'cpp') ?></p>

				<br />

				<p><label><input type="checkbox" name="cp_options[enable_wpcli]"<?php checked( $cp_options['enable_wpcli'], '1' ) ?> /><?php esc_html_e('Enable WP-CLI integration.','cpp') ?></label></p>
				<p class="description"><?php printf( esc_html__('Enter %s to display the available command line options.', 'cpp'), '<code>wp cpp help</code>' ) ?></p>

				<br />

				<p><label><input type="checkbox" name="cp_options[disable_wpcron]"<?php checked( $cp_options['disable_wpcron'], '1' ) ?> /><?php esc_html_e('Disable WP-Cron when running the profiler.','cpp') ?></label></p>

				<p class="description"><?php esc_html_e('This option will prevent WP-Cron to run scheduled tasks in the background that could affect the results of the profiler.', 'cpp') ?></p>

				<br />

				<p><label><input type="checkbox" name="cp_options[disable_db-php]"<?php checked( $cp_options['disable_db-php'], '1' ) ?> /><?php esc_html_e('Disable wp-content/db.php when running the profiler.','cpp') ?></label></p>
				<p class="description"><?php esc_html_e('This option will temporarily disable any potential wp-content/db.php script found on your site to prevent it from interfering with the profiler and database queries.', 'cpp') ?></p>

				<br />

				<p><?php esc_html_e('Stop the profiler and throw an error if the server returns any of the following HTTP status codes:', 'cpp' ) ?></p>
				<p><label><input type="checkbox" name="cp_options[http_response_300]" value="1"<?php checked( $http_response_300, '1' ) ?> /><?php esc_html_e('3xx redirection (301 Moved Permanently, 302 Found etc)','cpp') ?></label></p>
				<p><label><input type="checkbox" name="cp_options[http_response_400]" value="1"<?php checked( $http_response_400, '1' ) ?> /><?php esc_html_e('4xx client errors (400 Bad Request, 403 Forbidden, 404 Not Found etc)','cpp') ?></label></p>
				<p><label><input type="checkbox" name="cp_options[http_response_500]" value="1"<?php checked( $http_response_500, '1' ) ?> /><?php esc_html_e('5xx server errors (500 Internal Server Error, 503 Service Unavailable etc)','cpp') ?></label></p>

			</td>
		</tr>
	</table>

	<p><input type="submit" name="save-settings" class="button-primary" value="<?php esc_attr_e('Save Settings', 'cpp') ?>" /></p>

</form>
<?php

// =====================================================================
// Save and validate the settings.

function cpp_save_settings() {

	$cp_options = get_option( 'cpp' );

	// Paths
	if ( empty( $_POST['cp_options']['show_paths'] ) || ! in_array( $_POST['cp_options']['show_paths'], ['absolute', 'relative' ] ) ) {
		$cp_options['show_paths'] = 'relative';
	} else {
		$cp_options['show_paths'] = $_POST['cp_options']['show_paths'];
	}

	// Name vs slug
	if ( empty( $_POST['cp_options']['display_name'] ) || ! in_array( $_POST['cp_options']['display_name'], ['full', 'slug' ] ) ) {
		$cp_options['display_name'] = 'full';
	} else {
		$cp_options['display_name'] = $_POST['cp_options']['display_name'];
	}

	// Truncate names
	if ( empty( $_POST['cp_options']['truncate_name'] ) || ! preg_match( '/^\d+$/', ( $_POST['cp_options']['truncate_name'] ) ) ) {
		$cp_options['truncate_name'] = 30;
	} else {
		$cp_options['truncate_name'] = (int) $_POST['cp_options']['truncate_name'];
	}

	// chart type
	if ( empty( $_POST['cp_options']['chart_type'] ) || ! in_array( $_POST['cp_options']['chart_type'], ['x', 'y' ] ) ) {
		$cp_options['chart_type'] = 'x';
	} else {
		$cp_options['chart_type'] = $_POST['cp_options']['chart_type'];
	}

	// Max plugins to display
	if ( empty( $_POST['cp_options']['chart_max_plugins'] ) || ! preg_match( '/^\d+$/', ( $_POST['cp_options']['chart_max_plugins'] ) ) ) {
		$cp_options['chart_max_plugins'] = 25;
	} else {
		$cp_options['chart_max_plugins'] = $_POST['cp_options']['chart_max_plugins'];
	}

	// Max row to display in a table
	if ( empty( $_POST['cp_options']['table_max_rows'] ) || ! preg_match( '/^\d+$/', ( $_POST['cp_options']['table_max_rows'] ) ) ) {
		$cp_options['table_max_rows'] = 30;
	} else {
		$cp_options['table_max_rows'] = $_POST['cp_options']['table_max_rows'];
	}

	// Truncate database queries
	if ( empty( $_POST['cp_options']['truncate_queries'] ) || ! preg_match( '/^\d+$/', ( $_POST['cp_options']['truncate_queries'] ) ) ) {
		$cp_options['truncate_queries'] = 500;
	} else {
		$cp_options['truncate_queries'] = (int) $_POST['cp_options']['truncate_queries'];
	}

	// Empty values
	if (! empty( $_POST['cp_options']['hide_empty_value'] ) ) {
		$cp_options['hide_empty_value'] = 1;
	} else {
		$cp_options['hide_empty_value'] = 0;
	}

	// Composer warning
	if (! empty( $_POST['cp_options']['warn_composer'] ) ) {
		$cp_options['warn_composer'] = 1;
	} else {
		$cp_options['warn_composer'] = 0;
	}

	// WP-Cron
	if (! empty( $_POST['cp_options']['disable_wpcron'] ) ) {
		$cp_options['disable_wpcron'] = 1;
	} else {
		$cp_options['disable_wpcron'] = 0;
	}

	// wp-content/db.php
	if (! empty( $_POST['cp_options']['disable_db-php'] ) ) {
		$cp_options['disable_db-php'] = 1;
	} else {
		$cp_options['disable_db-php'] = 0;
	}

	// WP-CLI integration
	if (! empty( $_POST['cp_options']['enable_wpcli'] ) ) {
		$cp_options['enable_wpcli'] = 1;
	} else {
		$cp_options['enable_wpcli'] = 0;
	}

	// HTTP status code
	$code 								= '';
	$cp_options['http_response']	= '';
	if (! empty( $_POST['cp_options']['http_response_300'] ) ) {
		$code .= '3|';
	}
	if (! empty( $_POST['cp_options']['http_response_400'] ) ) {
		$code .= '4|';
	}
	if (! empty( $_POST['cp_options']['http_response_500'] ) ) {
		$code .= '5';
	}
	$code = rtrim( $code, '|' );
	if (! empty( $code ) ) {
		$cp_options['http_response'] = "^(?:$code)\d{2}$";
	}

	return update_option( 'cpp', $cp_options );

}

// =====================================================================
// EOF
