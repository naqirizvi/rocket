<?php


if (! defined( 'ABSPATH' ) ) { die( 'Forbidden' ); }

// =====================================================================
// Display File I/O stats.

$buffer = cpp_get_profile_data( $profile_path, 'iostats' );
if ( isset( $buffer['error'] ) ) {
	return;
}
// Fetch options
$cp_options = get_option( 'cpp' );
// Horizontal vs vertical chart
if ( empty( $cp_options['chart_type'] ) || ! in_array( $cp_options['chart_type'], ['x', 'y' ] ) ) {
	$axis = 'x';
} else {
	$axis = $cp_options['chart_type'];
}

$label  = '';
$data   = '';
$color  = '';
$colorh = '';
$colorb = '';
$hidden = 0;
$total_calls = 0;
foreach( $buffer as $k => $slugs ) {
	if ( empty( $slugs[1] ) && ! empty( $cp_options['hide_empty_value'] ) ) {
		$hidden++;
		continue;
	}
	$label			.= "'" . esc_js( $slugs[0] ) ."',";
	$data 			.= (int) $slugs[1] .',';
	$total_calls	+= $slugs[1];
}
$label = rtrim( $label, ',' );
$data  = rtrim( $data, ',' );

?>
<div style="width:80vw;margin:auto">
	<canvas id="myChart"></canvas>
</div>
<script>
jQuery(document).ready(function() {
	'use strict';
	cpjspro_iostats_chart('<?php echo $axis ?>', [<?php echo $label ?>],
		[<?php echo $data ?>], <?php echo $total_calls ?>
	);
});
</script>
<?php
// Actions below stats
$save_png   = 1;
$save_csv   = 1;
$rotate_img = 1;
$type       = 'iostats';
// =====================================================================
// EOF
