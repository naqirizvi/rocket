<?php


if (! defined( 'ABSPATH' ) ) { die( 'Forbidden' ); }

// =====================================================================
// Display Profiles List tab.

echo cpp_display_tabs( 2 );

// Look for actions
$section = 0;
$section_list = [
	1 => esc_html__('Plugins & theme performance', 'cpp'),
	2 => esc_html__('Scripts performance', 'cpp'),
	3 => esc_html__('Methods & functions performance', 'cpp'),
	4 => esc_html__('Database queries performance', 'cpp'),
	5 => esc_html__('File I/O list', 'cpp'),
	6 => esc_html__('File I/O statistics', 'cpp'),
	7 => esc_html__('Disk I/O statistics', 'cpp')
];
if (! empty( $_REQUEST['action'] ) && $_REQUEST['action'] == 'view_profile' &&
	! empty( $_REQUEST['section'] ) && ! empty( $section_list[ $_REQUEST['section'] ] ) ) {
	// Make sure the profile exists and get its full path
	$profile_path = cpp_get_profile_path( $_REQUEST['id'] );
	if ( $profile_path !== false ) {
		$section = (int) $_REQUEST['section'];
		$id = $_REQUEST['id'];
	}
}

// Search query: get rid of slashes added by WordPress
if (! empty( $_REQUEST['s'] ) ) {
	$_REQUEST['s'] = stripslashes( $_REQUEST['s'] );
}
$q = '';
if (! empty( $_SERVER['QUERY_STRING'] ) ) {
	$q = ' action="?'. esc_attr( $_SERVER['QUERY_STRING'] ) .'"';
}

if (! empty( $section ) ) {
	// View selected profile
	require 'menu_view_profile.php';

} else {
	// Show profiles list table

	// Load WP_List_Table class
	if (! class_exists( 'WP_List_Table' ) ) {
		 require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
	}
	require 'class-table-profiles.php';
	$CPTableProfiles = new CodeProfilerPro_Table_Profiles();

	// Profile(s) deletion
	if ( isset( $_REQUEST['action'] ) && $_REQUEST['action'] == 'delete_profiles' &&
		! empty( $_REQUEST['profiles'] ) ) {
		// Verify security nonce
		if ( wp_verify_nonce( $_REQUEST['_wpnonce'], 'bulk-'. $CPTableProfiles->_args['plural'] ) === false ) {
			wp_nonce_ays( 'bulk-' . $CPTableProfiles->_args['plural'] );
		}

		$error = $CPTableProfiles->delete_profiles( $_REQUEST['profiles'] );
		if ( $error === true ) {
			printf(
				CPP_ERROR_NOTICE,
				esc_html__('Some errors occured when trying to delete the selected profiles.', 'cpp' )
			);
		} else {
			printf(
				CPP_UPDATE_NOTICE,
				esc_html__('The selected profiles were deleted.', 'cpp' )
			);
		}
	}

	?>
	<br />
	<form id="profile-form" method="post"<?php echo $q ?> onsubmit="return cpjspro_search_query();">
	<?php
		// Search query
		if (! empty( $_REQUEST['s'] ) ) {
			echo '<span class="subtitle">';
			printf( esc_html__( 'Filter: %s' ), '<code>' . esc_html( $_REQUEST['s'] ) . '</code>' );
			echo '</span>';
		}
		$CPTableProfiles->prepare_items();
		$CPTableProfiles->search_box( esc_attr__('Filter', 'cpp'), 'search_id' );
		$CPTableProfiles->display();
		?>
	</form>
	<!-- Help -->
	<div class="tablenav bottom">
		<div id="cp-footer-help" style="display:none">
			<?php
			 $type = 'profiles_list';
			 include 'help.php';
			 ?>
			<br />
		</div>
		<div class="alignleft actions bulkactions">
			<input type="button" class="button-primary" style="min-width:100px" value="<?php esc_attr_e('Help', 'cpp' )?>" onclick="jQuery('#cp-footer-help').slideToggle(500);"/>
		</div>
		<div class="tablenav-pages">
			<a type="button" class="button-secondary" title="<?php esc_attr_e('Click to download as a CVS file', 'cpp' )?>" onclick='window.location="?page=cpp&cp-download-csv=0000000000.0&cp-type=profiles&_wpnonce=<?php echo wp_create_nonce('cp-download-csv') ?><?php
		if (! empty( $_REQUEST['s'] ) ) {
			echo '&s='. esc_attr( $_REQUEST['s'] );
		}
		?>"'/><span class="dashicons dashicons-download" style="display: inline-block;vertical-align: middle;"></span><?php esc_attr_e('Download as a CSV file', 'cpp' )?></a>
		</div>
	</div>
<?php
}
// =====================================================================
// EOF
