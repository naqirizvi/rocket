<?php
/* Those extra strings come from the free version. */
__('Explore the Pro version', 'cpp');
__('Rate it on WordPress.org', 'cpp');
__('The "%s" option is only available in the pro version of C P.', 'cpp');
__('Run the profiler on the frontend', 'cpp');
__('Pro version only', 'cpp');
__('Profile your blog with C P.', 'cpp');
__('Plugins & Theme Performance', 'cpp');
__('File I/O Statistics', 'cpp');
__('Disk I/O Statistics', 'cpp');
__('Pro Features', 'cpp');
__('This chart shows the execution time of all activated plugins and the current theme, in seconds and percentage, for the current profile.', 'cpp');
__('WordPress website performance profiling made easy.', 'cpp');
__('C P P makes it super easy to locate any performance problem in your themes or plugins by analyzing their scripts, classes & methods, functions as well as monitoring all file I/O operations.', 'cpp');
__('That section shows the time it took for each PHP script to execute its code while the website was loading. The "Time" column shows their respective processing time in seconds and, with a green horizontal bar, the percentage it represents. ', 'cpp');
__('Click to enlarge image.', 'cpp');
__('That section shows the time it took for each class/method or function to execute its code while the website was loading. The "Time" column shows their respective processing time in seconds and, with a green horizontal bar, the percentage it represents. The "Caller" column shows the sum of all functions that called it.', 'cpp');
__('The two action links below each item let you view the corresponding function and the list of callers.', 'cpp');
__('That section shows the time it took to process each database query.', 'cpp');
__('That section shows all files and directories with their respective I/O operations that occurred while the website was loading. The default sorting order is based on the control flow, i.e., the order in which the PHP code was executed while the website was loading. The following 10 operations are monitored by C P:', 'cpp');
__('Create your own graphs and reports effortlessly.', 'cpp');
__('All charts and tables can be exported as a CSV file (comma-separated values) that you can open with your favorite spreadsheet editor in order to create graphs and reports.', 'cpp');
__('Learn more about C P P.', 'cpp');
__('The MU plugin is not loaded, please check the log', 'cpp');
__('C P P is active on this site, please disable it first if you want to run the free version.', 'cpp');
__('Go Pro', 'cpp');
